package com.tweetApp.dao;



import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.PaginatedScanList;
import com.tweetApp.model.Tweet;


@Repository
public class TweetDao {

    private DynamoDBMapper dynamoDBMapper;

    @Autowired
    public TweetDao(DynamoDBMapper dynamoDBMapper) {
        this.dynamoDBMapper = dynamoDBMapper;
    }

    public Tweet getTweet(String tweetId) {
        return dynamoDBMapper.load(Tweet.class, tweetId);
    }

    public Tweet createTweet(Tweet tweet) {
    	tweet.setReplies(new ArrayList<Tweet>());
    	tweet.setDate(new Date());
        dynamoDBMapper.save(tweet);
        return tweet;
    }

	public PaginatedScanList<Tweet> getAllTweet() {
		
		return dynamoDBMapper.scan(Tweet.class, new DynamoDBScanExpression());
		
	}
	
	public String deleteTweet(String id) {
		
		dynamoDBMapper.delete(dynamoDBMapper.load(Tweet.class, id));
		return "Tweet Deleted.";
	}
	
	public String updateTweet(String id,String description) {
		
		Tweet tweet=dynamoDBMapper.load(Tweet.class, id);
		tweet.setDescription(description);
		tweet.setDate(new Date());
		dynamoDBMapper.save(tweet);
		return "Tweet Updated.";
	}
	
	public String likeTweet(String id) {
		Tweet tweet=dynamoDBMapper.load(Tweet.class, id);
		tweet.setLikes(tweet.getLikes() + 1);
		dynamoDBMapper.save(tweet);
		return "Tweet liked";
	}
	
}
