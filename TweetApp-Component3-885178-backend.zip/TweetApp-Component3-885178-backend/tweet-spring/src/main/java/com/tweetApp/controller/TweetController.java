package com.tweetApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.dynamodbv2.datamodeling.PaginatedScanList;
import com.amazonaws.services.sns.AmazonSNSClient;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.SubscribeRequest;
import com.tweetApp.dao.TweetDao;
import com.tweetApp.model.Tweet;

@CrossOrigin(origins = "*",maxAge = 3600)
@RestController
public class TweetController {
    
    private @Autowired TweetDao tweetDao;
    
    @Autowired
    private AmazonSNSClient amazonSNSClient;
    
    String TOPIC_ARN="arn:aws:sns:us-east-1:372945716648:tweetapp-topic";
    
    @RequestMapping(value = "/add", produces = {"application/json"},
            method = RequestMethod.POST)
    public ResponseEntity<Tweet> postATweet(@RequestBody Tweet tweet) {
        try {
        	Tweet response = tweetDao.createTweet(tweet);
        	
//        	SubscribeRequest request=new SubscribeRequest(TOPIC_ARN, "email", tweet.getEmail());
//        	amazonSNSClient.subscribe(request);
        	
        	PublishRequest publishRequest=new PublishRequest(TOPIC_ARN,tweet.getEmail()+"posted a tweet\n"+tweet.getDescription(),tweet.getEmail()+" posted a tweet");
        	amazonSNSClient.publish(publishRequest);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (AmazonServiceException e) {
            throw new ResponseStatusException(HttpStatus.valueOf(e.getStatusCode()), e.getMessage(),
                    e);
        } catch (AmazonClientException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), e);
        }
    }
    
    
    @RequestMapping(value = "/all", produces = {"application/json"},
            method = RequestMethod.GET)
    public ResponseEntity<PaginatedScanList<Tweet>> getAllTweet() {
        try {
        	PaginatedScanList<Tweet> response = tweetDao.getAllTweet();
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (AmazonServiceException e) {
            throw new ResponseStatusException(HttpStatus.valueOf(e.getStatusCode()), e.getMessage(),
                    e);
        } catch (AmazonClientException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), e);
        }
    }
    
    

    @RequestMapping(value = "/tweet/{tweetId}", produces = {"application/json"},
            method = RequestMethod.GET)
    public ResponseEntity<Tweet> getTweetByTweetId(@PathVariable String tweetId) {
        try {
        	Tweet response = tweetDao.getTweet(tweetId);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (AmazonServiceException e) {
            throw new ResponseStatusException(HttpStatus.valueOf(e.getStatusCode()), e.getMessage(),
                    e);
        } catch (AmazonClientException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), e);
        }
    }
    
    @RequestMapping(value = "/delete/{id}", produces = {"application/json"},
            method = RequestMethod.DELETE)
    public ResponseEntity<String> deleteTweet(@PathVariable(name = "id") String id) {
        try {
        	String response = tweetDao.deleteTweet(id);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (AmazonServiceException e) {
            throw new ResponseStatusException(HttpStatus.valueOf(e.getStatusCode()), e.getMessage(),
                    e);
        } catch (AmazonClientException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), e);
        }
    }
    
    @RequestMapping(value = "/update/{id}", produces = {"application/json"},
            method = RequestMethod.PUT)
    public ResponseEntity<String> updateTweet(@PathVariable(name = "id") String id,
			@RequestBody Tweet tweet) {
        try {
        	String response = tweetDao.updateTweet(id,tweet.getDescription());
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (AmazonServiceException e) {
            throw new ResponseStatusException(HttpStatus.valueOf(e.getStatusCode()), e.getMessage(),
                    e);
        } catch (AmazonClientException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), e);
        }
    }
    
    @RequestMapping(value = "/like/{id}", produces = {"application/json"},
            method = RequestMethod.PUT)
    public ResponseEntity<String> likeTweet(@PathVariable(name = "id") String id) {
        try {
        	String response = tweetDao.likeTweet(id);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (AmazonServiceException e) {
            throw new ResponseStatusException(HttpStatus.valueOf(e.getStatusCode()), e.getMessage(),
                    e);
        } catch (AmazonClientException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), e);
        }
    }

}
