package com.tweetApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TweetSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
